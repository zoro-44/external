public class example
{
public static void main(String[] args)
{
int a=20,b=30,c;
c=a*b;
System.out.println("Hello world");
System.out.println("value of c is "+c);
}
}

